// 获取页面中id为'line'的DOM元素，用于渲染折线图
var chartDom_line = document.getElementById('line');
// 使用echarts库初始化图表实例
var myChart_line = echarts.init(chartDom_line);

// 定义折线图的配置项
option_line = {
    // 图表标题配置
    title: {
        text: '每日销量折线图', // 标题文本
        left: 'center',        // 标题位置居中
        textStyle: {           // 标题样式
            color: 'white',     // 标题颜色为白色
            fontSize: 14,       // 字体大小为14px
            fontWeight: 'bold'  // 字体加粗
        }
    },
    // X轴配置
    xAxis: {
        type: 'category',      // 类目轴，适用于离散的类目数据
        data: [],              // X轴数据，初始为空数组，将通过Ajax请求填充
    },
    // Y轴配置
    yAxis: {
        type: 'value'          // 数值轴，适用于连续型数据
    },
    // 系列列表，每个系列通过类型决定自己的图表类型
    series: [{
        data: [],              // 系列数据，初始为空数组，将通过Ajax请求填充
        type: 'line',          // 系列类型为折线图
    }],
    // 提示框组件，用于展示数据信息
    tooltip: {}
};

// 使用jQuery的Ajax方法获取路由数据
$.ajax({
    url: "/line",              // 请求的URL地址
    success: function (data) { // 请求成功时的回调函数
        // 将获取到的数据填充到配置项中
        option_line.xAxis.data = data['日期'];    // 设置X轴数据
        option_line.series[0].data = data['总销量']; // 设置系列数据
        // 使用设置好的配置项刷新图表
        myChart_line.setOption(option_line);
    },
    error: function (xhr, type, errorThrown) { // 请求失败时的回调函数
        // 此处可以处理错误情况，例如显示错误信息
    }
});
