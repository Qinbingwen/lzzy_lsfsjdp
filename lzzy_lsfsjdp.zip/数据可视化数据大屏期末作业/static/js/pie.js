// 获取页面中id为'pie'的DOM元素，用于渲染饼图
var chartDom_pie = document.getElementById('pie');
// 使用echarts库初始化图表实例
var myChart_pie = echarts.init(chartDom_pie);

// 定义饼图的配置项
option_pie = {
    // 图表标题配置
    title: {
        text: '口味销量占比饼图', // 标题文本
        left: 'center',          // 标题位置居中
        textStyle: {             // 标题样式
            color: 'white',       // 标题颜色为白色
            fontSize: 14,         // 字体大小为14px
            fontWeight: 'bold'    // 字体加粗
        }
    },
    // 系列列表，每个系列通过类型决定自己的图表类型
    series: [
        {
            name: '',             // 系列名称，此处留空
            type: 'pie',          // 系列类型为饼图
            radius: ['20%', '40%'], // 饼图的半径大小，分别为内半径和外半径
            center: ['50%', '50%'], // 饼图的中心位置，相对于容器
            data: [],             // 系列数据，初始为空数组，将通过Ajax请求填充
            label: {              // 标签配置
                formatter: '{b}\n数量: {c}\n占比: {d}%' // 标签内容格式化，显示项目名称、数量和占比
            },
        }
    ],
    // 提示框组件，用于展示数据信息
    tooltip: {}
};

// 使用jQuery的Ajax方法获取路由数据
$.ajax({
    url: "/pie",                // 请求的URL地址
    success: function (data) {  // 请求成功时的回调函数
        // 将获取到的数据填充到配置项中
        option_pie.series[0].data = data; // 设置系列数据
        // 使用设置好的配置项刷新图表
        myChart_pie.setOption(option_pie);
    },
    error: function (data) {    // 请求失败时的回调函数
        alert('数据请求失败');    // 弹出错误提示
    }
});
