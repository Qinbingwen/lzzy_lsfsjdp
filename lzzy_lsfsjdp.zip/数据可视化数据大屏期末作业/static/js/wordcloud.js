// 获取页面中id为'wordcloud'的DOM元素，用于渲染词云图
var chartDom_wordcloud = document.getElementById('wordcloud');
// 使用echarts库初始化图表实例
var myChart_wordcloud = echarts.init(chartDom_wordcloud);

// 定义词云图的配置项
option_wordcloud = {
    // 图表标题配置
    title: {
        text: '城市线下网点词云图', // 标题文本
        left: 'center',            // 标题位置居中
        textStyle: {               // 标题样式
            color: 'white',         // 标题颜色为白色
            fontSize: 14,           // 字体大小为14px
            fontWeight: 'bold'      // 字体加粗
        }
    },
    series: [
        {
            type: 'wordCloud',       // 系列类型为词云图
            data: [],                // 系列数据，初始为空数组，将通过Ajax请求填充
            shape: 'circle',         // 词云图的形状为圆形
            sizeRange: [20, 60],     // 词云图中词的大小范围，从20px到60px
            rotationRange: [-90, 90],// 词云图中词的旋转范围，从-90度到90度
            rotationStep: 45,        // 词云图中词的旋转步长为45度
            textStyle: {
                fontFamily: 'sans-serif', // 字体为无衬线字体
                normal: {
                    color: function () {
                        // 随机生成颜色值
                        return 'rgb(' + [
                            Math.round(Math.random() * 160), // 随机红色值
                            Math.round(Math.random() * 160), // 随机绿色值
                            Math.round(Math.random() * 160)  // 随机蓝色值
                        ].join(',') + ')'; // 将RGB值组合成颜色字符串
                    }
                },
            }
        }
    ],
};

// 使用jQuery的Ajax方法获取词云图数据
$.ajax({
    url: '/wordcloud',  // 请求的URL地址，指向服务器上用于获取词云数据的路由
    success: function (data) {  // 请求成功时的回调函数
        // 将获取到的数据填充到配置项中
        option_wordcloud.series[0].data = data;
        // 使用设置好的配置项刷新图表
        myChart_wordcloud.setOption(option_wordcloud);
    },
    error: function (data) {  // 请求失败时的回调函数
        // 弹出错误提示
        alert('数据请求失败');
    }
});
