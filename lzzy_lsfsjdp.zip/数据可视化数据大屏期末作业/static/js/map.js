// 获取页面中id为'map'的DOM元素，用于渲染中国地图
var chartDom_map = document.getElementById('map');
// 使用echarts库初始化图表实例
var myChart_map = echarts.init(chartDom_map);

// 定义中国地图的配置项
option_map = {
    series: [
        {
            type: "map",           // 系列类型为地图
            mapType: "china",      // 指定地图类型为中国地图
            label: {
                show: true,        // 显示地名标签
                color: '#ffffff'   // 设置地名的文字颜色为白色
            },
            roam: true,            // 允许用户缩放和平移
            data: [],              // 初始数据为空，后续通过Ajax请求更新
        }
    ],
    title: {
        text: '各省份销量地图',     // 设置标题文本
        left: 'center',          // 标题居中
        textStyle: {             // 标题文字样式
            color: 'white',       // 设置标题颜色为白色
            fontSize: 14,         // 设置字体大小
            fontWeight: 'bold'    // 设置字体加粗
        }
    },
    tooltip: {},                 // 提示框组件，用于展示数据信息
    visualMap: {
        max: 500000,             // 视觉映射组件的最大值
        min: 0,                  // 视觉映射组件的最小值
        inRange: {
            color: ['#006d77', '#00e9ff', '#a3f7ff'] // 定义数据范围的颜色渐变，从深蓝色到浅蓝色
        }
    }
};

// 使用jQuery的Ajax方法获取地图数据
$.ajax({
    url: "/map",                // 请求的URL地址
    success: function (data) {  // 请求成功时的回调函数
        option_map.series[0].data = data[0]; // 设置系列数据
        myChart_map.setOption(option_map);   // 使用设置好的配置项刷新图表
    },
    error: function (xhr, type, errorThrown) { // 请求失败时的回调函数
        // 可以在这里处理错误，例如显示错误信息
    }
});

// 监听下拉选择框的变化
var select = document.getElementById("select");
select.addEventListener("change", function () {
    // 当下拉框的选项发生变化时，再次通过Ajax请求获取对应的数据
    $.ajax({
        url: "/map",            // 请求的URL地址
        success: function (data) {
            // 根据下拉框当前选中的值更新地图数据
            option_map.series[0].data = data[select.value];
            myChart_map.setOption(option_map); // 使用更新后的配置项刷新图表
        },
        error: function (xhr, type, errorThrown) { // 请求失败时的回调函数
            // 可以在这里处理错误，例如显示错误信息
        }
    });
});
