// 获取页面中id为'bar'的DOM元素，用于渲染柱状图
var chartDom_bar = document.getElementById('bar');
// 使用echarts库初始化图表实例
var myChart_bar = echarts.init(chartDom_bar);

// 定义柱状图的配置项
option_bar = {
    // 图表标题配置
    title: {
        text: '各省份销量柱形图', // 标题文本
        left: 'center',          // 标题位置居中
        textStyle: {             // 标题样式
            color: 'white',       // 标题颜色为白色
            fontSize: 14,         // 字体大小为14px
            fontWeight: 'bold'    // 字体加粗
        }
    },
    // X轴配置
    xAxis: {
        type: 'category',        // 类目轴，适用于离散的类目数据
        data: [],                // X轴数据，初始为空数组，将通过Ajax请求填充
    },
    // Y轴配置
    yAxis: {
        type: 'value'            // 数值轴，适用于连续型数据
    },
    // 系列列表，每个系列通过类型决定自己的图表类型
    series: [{
        data: [],                // 系列数据，初始为空数组，将通过Ajax请求填充
        type: 'bar',             // 系列类型为柱状图
    }],
    // 提示框组件，用于展示数据信息
    tooltip: {}
};

// 使用jQuery的Ajax方法获取路由数据
$.ajax({
    url: "/bar",                // 请求的URL地址
    success: function (data) {  // 请求成功时的回调函数
        // 将获取到的数据填充到配置项中
        option_bar.xAxis.data = data['省份'];    // 设置X轴数据
        option_bar.series[0].data = data['总销量']; // 设置系列数据
        // 使用设置好的配置项刷新图表
        myChart_bar.setOption(option_bar);
    },
    error: function (xhr, type, errorThrown) { // 请求失败时的回调函数
        // 此处可以处理错误情况，例如显示错误信息
    }
});
