# 导入 Flask 类，用于创建 Flask 应用实例。
from flask import Flask, jsonify, render_template
import utils
import pandas as pd
import random

# 创建 Flask 应用实例
app = Flask(__name__)

# 定义根路由，当用户访问网站根目录时，返回 index.html 模板
@app.route('/')
def index():
    return render_template('index.html')

# 定义 /bar 路由，返回柱状图所需的数据
@app.route('/bar')
def bar():
    
    bar_data = utils.get_province_data()[0]# 获取各省份销量数据
    
    df_pro = pd.DataFrame(bar_data, columns=['省份', '总销量'])# 将数据转换为 DataFrame，并指定列名
    
    df_pro['总销量'] = (df_pro['总销量'] / 10000).round(2)# 将总销量单位转换为万，并保留两位小数
    
    df_pro = df_pro.sort_values(by='总销量', ascending=False).head(10) # 按总销量降序排列，并取前10条数据
    
    return jsonify(df_pro.to_dict(orient='list'))# 将 DataFrame 转换为字典形式，并以列表形式返回

# 定义 /line 路由，返回折线图所需的数据
@app.route('/line')
def line():
    
    data = utils.get_daily_data()# 获取每日销量数据
    
    df = pd.DataFrame(data, columns=['日期', '总销量'])# 将数据转换为 DataFrame，并指定列名
    
    df['日期'] = df['日期'].dt.strftime('%m-%d')# 将日期格式化为月-日
    
    df['总销量'] = (df['总销量'] / 10000).round(1)# 将总销量单位转换为万，并保留一位小数
    
    return jsonify(df.to_dict(orient='list'))# 将 DataFrame 转换为字典形式，并以列表形式返回

# 定义 /map 路由，返回地图所需的数据
@app.route('/map')
def map():
    
    total_data, spicy_data = utils.get_province_data()# 获取各省份总销量和辣味销量数据
    
    # 初始化两个空列表，用于存储转换后的数据
    data_list_total = []
    data_list_spicy = []
    
    # 遍历总销量数据，并添加到 data_list_total 列表中
    for i in total_data:
        data_list_total.append({'name': i[0], 'value': i[1]})
        
    # 遍历辣味销量数据，并添加到 data_list_spicy 列表中
    for i in spicy_data:
        data_list_spicy.append({'name': i[0], 'value': i[1]})
        
    # 返回包含两个列表的列表，分别表示总销量和辣味销量数据
    return jsonify([data_list_total, data_list_spicy])

# 定义 /pie 路由，返回饼图所需的数据
@app.route('/pie')
def pie():
    # 获取口味销量数据
    pie_data = utils.get_taste_data()
    # 构造数据列表，每个字典包含口味名称和销量
    data_list = [
        {'name': '原味', 'value': pie_data[0][0]},
        {'name': '麻辣味', 'value': pie_data[0][1]},
        {'name': '酸菜味', 'value': pie_data[0][2]},
        {'name': '番茄味', 'value': pie_data[0][3]},
        {'name': '加辣加臭', 'value': pie_data[0][4]},
        {'name': '升级版', 'value': pie_data[0][5]}
    ]
    # 以列表形式返回数据
    return jsonify(data_list)

# 定义 /wordcloud 路由，返回词云图所需的数据
@app.route('/wordcloud')
def wordcloud():
    
    wordcloud_data = utils.get_city_data()# 获取城市数据
    
    data_list = []# 初始化空列表，用于存储词云图数据
    
    for i in wordcloud_data:
        data_list.append({'name': i[0], 'value': random.randint(0, 100)})# 遍历城市数据，为每个城市生成随机销量，并添加到 data_list 列表中
    
    return jsonify(data_list)# 以列表形式返回数据

# 定义 /today 路由，返回今日销售额数据
@app.route('/today')
def today():
    
    today_sales = utils.get_daily_data()[-1][-1]# 获取今日销售额
    
    return jsonify(today_sales)# 以单个值形式返回数据

# 定义 /total 路由，返回累计销售额数据
@app.route('/total')
def total():
    
    total_sales = sum([i[-1] for i in utils.get_daily_data()])# 获取累计销售额
    
    return jsonify(total_sales)# 以单个值形式返回数据

# 定义 /charts 路由，返回 charts.html 模板
@app.route('/charts')
def charts():
    return render_template('charts.html')

# 配置 Flask 应用，使得返回的 JSON 数据支持中文编码
app.config['JSON_AS_ASCII'] = False

# 当脚本被直接运行时，启动 Flask 应用
# '0.0.0.0' 表示监听所有可用的网络接口，debug=True 启用调试模式
if __name__ == '__main__':
    app.run('0.0.0.0', debug=True)
