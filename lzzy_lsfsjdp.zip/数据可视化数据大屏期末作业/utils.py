import pymysql  # 导入pymysql模块，用于数据库操作

# 创建数据库连接和游标的函数
def get_conn():
    # 使用pymysql.connect()方法连接到数据库
    # 其中包含了数据库服务器地址、端口、用户名、密码、数据库名称和字符集等信息
    conn = pymysql.connect(
        host="abc001",    # 数据库服务器地址
        port=3306,           # 数据库服务器端口号
        user="root",        # 数据库用户名
        password="abc123456", # 数据库用户密码
        db="abc",         # 要连接的数据库名称
        charset="utf8"       # 使用的字符集
    )
    #注意修改为实际的数据库信息
    
    # 创建一个游标对象，用于执行SQL查询和获取结果
    cursor = conn.cursor()
    # 返回数据库连接对象和游标对象
    return conn, cursor

# 关闭数据库连接和游标的函数
def close_conn(conn, cursor):
    # 如果游标对象存在，则关闭游标
    if cursor:
        cursor.close()
    # 如果数据库连接对象存在，则关闭连接
    if conn:
        conn.close()

# 执行SQL查询的函数
def query(sql):
    """
    :param sql: SQL查询语句字符串
    :return: 查询结果，以元组形式返回
    """
    # 调用get_conn函数获取数据库连接和游标
    conn, cursor = get_conn()
    # 使用游标对象的execute方法执行SQL查询语句
    cursor.execute(sql)
    # 使用游标对象的fetchall方法获取所有查询结果
    res = cursor.fetchall()
    # 调用close_conn函数关闭数据库连接和游标
    close_conn(conn, cursor)
    # 返回查询结果
    return res

# 获取省份销售数据的函数
def get_province_data():
    # 定义查询总销售量的SQL语句
    sql_total = ''' 
        SELECT
            province, 
            origin + spicy + sauerkraut + tomato + smelly + upgrade AS total
        FROM sale_provinces
    '''
    # 定义查询辣味销售量的SQL语句
    sql_spicy = '''
        SELECT
            province,
            spicy
        FROM sale_provinces
    '''
    # 执行总销售量查询，获取结果
    res_total = query(sql_total)
    # 执行辣味销售量查询，获取结果
    res_spicy = query(sql_spicy)
    # 返回总销售量和辣味销售量结果
    return res_total, res_spicy

# 获取每日销售数据的函数
def get_daily_data():
    # 定义查询每日销售量的SQL语句
    sql='''
        select
            date,
            origin+spicy+sauerkraut+tomato+smelly+upgrade as total
        from sale_products
    '''
    # 执行查询，获取结果
    res=query(sql)
    # 返回查询结果
    return res

# 获取城市数据的函数
def get_city_data():
    # 定义查询城市信息的SQL语句
    sql='''
        select city from national_network  
    '''
    # 执行查询，获取结果
    res=query(sql)
    # 返回查询结果
    return res

# 获取口味数据的函数，用于生成饼图
def get_taste_data():
    # 定义查询各种口味销售量的SQL语句
    sql = '''
        SELECT
            SUM(origin),
            SUM(spicy),
            SUM(sauerkraut),
            SUM(tomato),
            SUM(smelly),
            SUM(upgrade)
        FROM sale_products
    '''
    # 执行查询，获取结果
    res = query(sql)
    # 返回查询结果
    return res

# 获取城市数据的函数，用于生成词云图
def get_city_data():
    # 定义查询城市信息的SQL语句
    sql = '''
        SELECT city FROM national_network
    '''
    # 执行查询，获取结果
    res = query(sql)
    # 返回查询结果
    return res

# 主函数，用于测试查询结果
if __name__ == "__main__":
    # 调用get_province_data函数，打印省份销售数据
    r = get_province_data()
    print(r)
